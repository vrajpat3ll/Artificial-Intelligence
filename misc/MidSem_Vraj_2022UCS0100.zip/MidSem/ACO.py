from utils.ant_colony_optimisation import AntColonyOptimization as ACO

numCustomers = 5
B = 20

# 0 is the index for central depot
# numbering for customers starts from 1 
TravelTime = [
    [],
]
demandOfCustomer = [] # all values greater than zero
distanceBetweenDepotAndCustomer = []
ACO.run(TravelTime,capacityOfEachVehicle=B)
