# Vehicle Routing Problem Solver using Ant Colony Optimization

This Python script implements a solver for the Vehicle Routing Problem (VRP) using the Ant Colony Optimization (ACO) algorithm. The VRP is a complex optimization problem where the goal is to find the most efficient routes for a fleet of vehicles to deliver goods to a set of customers.

## Table of Contents

1. [Overview](#overview)
2. [How It Works](#how-it-works)
3. [Parameters](#parameters)
4. [Example](#example)
5. [Customization](#customization)

## Overview

The problem is a generalization of the Traveling Salesman Problem (TSP). In this, we have:

- A depot where vehicles start and end their routes
- A set of customers with known demands
- A fleet of vehicles with limited capacity

Objective: to minimize the total travel time while satisfying all customer demands and respecting vehicle capacities.

This solver uses Ant Colony Optimization.

## How It Works

The main steps of the algorithm are:

1. Initialize parameters and pheromone matrix.
2. For each iteration:
   - Construct tours for each ant (vehicle).
   - Evaluate the solution.
   - Update the best solution if necessary.
   - Update pheromones based on tour quality.
3. Return the best solution found.


## Parameters

When creating a `VRPSolver` instance, you need to provide the following parameters:

- `numCustomers`: Number of customers (excluding depot)
- `maxVehicles`: Maximum number of vehicles available
- `alpha`: Pheromone influence factor
- `beta`: Distance influence factor
- `evaporationRate`: Rate at which pheromone evaporates
- `iterations`: Number of iterations to run the algorithm
- `capacity`: Maximum capacity of each vehicle
- `demand`: List of customer demands (including depot at index 0)
- `timeMatrix`: Matrix of travel times between locations

## Example

The `solve()` method returns two values:

1. `bestTours`: A list of tours, where each tour is a list of customer indices visited by a vehicle.
2. `bestTourLengths`: A list of the total travel times for each tour.

The solver also prints a table showing the progress of the algorithm across iterations, including the best tour length found and the number of vehicles used in each iteration.

## Customization

You can customize the solver by adjusting the parameters when creating the `VRPSolver` instance. Here are some advices:

- Increase `iterations` for potentially better solutions at the cost of longer runtime.
- Adjust `alpha` and `beta` to change the balance between pheromone influence and distance influence.
- Modify `evaporationRate` to control how quickly the algorithm forgets poor solutions.