for question 5, use the command on terminal:
```python
python 5.py
```

state can be changed in the 5.py file.
change the startState in 5.py using the array []. it should contain numbers between [1, 16] only.
16 is for blank space.
we would have to provide a valid input for the state else it would not be able to solve it.


for question 4, use 
```python
python 4.py
```