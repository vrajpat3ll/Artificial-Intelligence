We are doing some extra work while running DFID!
- What? we are doing the complete search of the tree again at every depthBound.
- So we are paying extra cost for searching the same portion of the tree again.
- Is this cost worthwhile? 
- Why? Space - Linear, Quality - like BFS