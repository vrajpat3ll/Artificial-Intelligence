class Agent:
    '''
    This is the base class that solves the problem given to it.
    The functions given below are domain-dependent.
    '''

    def __init__(self) -> None:
        self.OPEN = []
        self.CLOSED = []
        self.nodesExpanded = 0

    def RemoveSeen(self, moves):
        if len(moves) == 0:
            return []

        newMoves = []
        if isinstance(self.OPEN, list):
            for move in moves:
                if move not in self.OPEN and move not in self.CLOSED:
                    newMoves.append(move)
            return newMoves
        else:
            for move in moves:
                if move not in self.CLOSED:
                    newMoves.append(move)
            return newMoves

    def PlanningSearch(self, startNode, goalNode, traversal, solution, dbg):
        # search-dependent
        pass

    def ConfigSearch(self, startNode, traversal, solution, dbg):
        # search-dependent
        pass

    def MoveGen(self, startNode):
        # domain-dependent
        pass

    def GoalTest(self, node):
        # domain-dependent
        pass
    
